import { Routes, Route } from 'react-router-dom'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import Home from './pages/Home'
import NewRequest from './pages/NewRequest'
import RequestSuccess from './pages/RequestSuccess'
import Requests from './pages/Requests'
import Offer from './pages/Offer'
import OfferSuccess from './pages/OfferSuccess'
import AdminLogin from './pages/AdminLogin'
import AdminDashboard from './pages/AdminDashboard'
import RequireAdmin from './components/RequireAdmin'

export default function App() {
  return (
    <>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/new-request" element={<NewRequest />} />
        <Route path="/request-success" element={<RequestSuccess />} />
        <Route path="/requests" element={<Requests />} />
        <Route path="/offer/:requestId" element={<Offer />} />
        <Route path="/offer-success" element={<OfferSuccess />} />
        <Route path="/admin-login" element={<AdminLogin />} />
        <Route path="/admin" element={<RequireAdmin><AdminDashboard /></RequireAdmin>} />
        <Route path="*" element={<Home />} />
      </Routes>
      <Footer />
    </>
  )
}
