import { NavLink } from 'react-router-dom'

export default function Footer() {
  return (
    <footer>
      <div className="wrap">
        <div className="foot-grid">
          <div>
            <div className="foot-brand"><img src="/assets/motlob-logo.jpg" alt="Motlob" /></div>
            <p style={{ fontSize: 14, lineHeight: 1.8, maxWidth: '38ch' }}>
              منصة Reverse Marketplace لطلب السيارات في مصر. اطلب عربيتك، وخلي العروض تيجيلك.
            </p>
          </div>
          <div>
            <h4>الموقع</h4>
            <ul>
              <li><NavLink to="/">الرئيسية</NavLink></li>
              <li><NavLink to="/requests">العربيات المطلوبة</NavLink></li>
              <li><NavLink to="/new-request">اطلب عربيتك</NavLink></li>
            </ul>
          </div>
          <div>
            <h4>للتجار وأصحاب المعارض</h4>
            <ul>
              <li><NavLink to="/requests">شوف الطلبات المتاحة</NavLink></li>
              <li><NavLink to="/admin">لوحة التحكم</NavLink></li>
            </ul>
          </div>
        </div>
        <div className="foot-bottom">
          <span>© 2026 Motlob. جميع الحقوق محفوظة.</span>
          <span>مصر</span>
        </div>
      </div>
    </footer>
  )
}
