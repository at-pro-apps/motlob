import { Navigate } from 'react-router-dom'
import { useAdminAuth } from '../context/AdminAuthContext'

export default function RequireAdmin({ children }) {
  const { session, isAdmin, loading } = useAdminAuth()

  if (loading) return null
  if (!session) return <Navigate to="/admin-login" replace />
  if (!isAdmin) {
    return (
      <main>
        <section>
          <div className="wrap">
            <div className="empty-state" style={{ maxWidth: 480, margin: '60px auto' }}>
              <div className="ei">🚫</div>
              <h3>لا تملك صلاحية الدخول</h3>
              <p>هذا الحساب مسجل دخول لكنه غير مضاف كـ Admin في قاعدة البيانات.</p>
            </div>
          </div>
        </section>
      </main>
    )
  }
  return children
}
