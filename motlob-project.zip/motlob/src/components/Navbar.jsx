import { useState } from 'react'
import { NavLink } from 'react-router-dom'

const links = [
  { to: '/', label: 'الرئيسية', end: true },
  { to: '/requests', label: 'العربيات المطلوبة' },
  { to: '/new-request', label: 'اطلب عربيتك' },
  { to: '/admin', label: 'لوحة التحكم' },
]

export default function Navbar() {
  const [open, setOpen] = useState(false)

  return (
    <header className="nav">
      <div className="wrap nav-inner">
        <NavLink className="brand" to="/" onClick={() => setOpen(false)}>
          <img src="/assets/motlob-logo.jpg" alt="Motlob" />
        </NavLink>

        <nav className="nav-links" style={open ? {
          display: 'flex', position: 'absolute', top: 72, right: 0, left: 0,
          background: '#fff', flexDirection: 'column', padding: '16px 24px',
          borderBottom: '1px solid var(--line)', gap: 14,
        } : undefined}>
          {links.map((l) => (
            <NavLink key={l.to} to={l.to} end={l.end} onClick={() => setOpen(false)}
              className={({ isActive }) => isActive ? 'active' : undefined}>
              {l.label}
            </NavLink>
          ))}
        </nav>

        <div className="nav-cta">
          <NavLink className="btn btn-outline btn-sm" to="/requests">عندي عربية مطلوبة</NavLink>
          <NavLink className="btn btn-primary btn-sm" to="/new-request">اطلب عربيتك</NavLink>
        </div>

        <button className="burger" aria-label="القائمة" onClick={() => setOpen((v) => !v)}>
          <span></span><span></span><span></span>
        </button>
      </div>
    </header>
  )
}
