import { STATUS_LABEL, STATUS_BADGE_CLASS } from '../lib/constants'

export default function StatusBadge({ status }) {
  return (
    <span className={`badge ${STATUS_BADGE_CLASS[status] || 'badge-new'}`}>
      {STATUS_LABEL[status] || status}
    </span>
  )
}
