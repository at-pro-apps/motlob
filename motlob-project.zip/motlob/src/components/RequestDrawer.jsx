import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabaseClient'
import { STATUS_LABEL, STATUS_BADGE_CLASS, OFFER_STATUS_LABEL } from '../lib/constants'
import { money, formatDateTime } from '../lib/format'
import { useToast } from '../context/ToastContext'

export default function RequestDrawer({ request, onClose, onChanged }) {
  const [offers, setOffers] = useState([])
  const [notes, setNotes] = useState([])
  const [noteText, setNoteText] = useState('')
  const [status, setStatus] = useState(request.status)
  const toast = useToast()

  useEffect(() => { load() }, [request.id])

  async function load() {
    const [{ data: offerRows }, { data: noteRows }] = await Promise.all([
      supabase.from('seller_offers').select('*').eq('request_id', request.id).order('created_at', { ascending: false }),
      supabase.from('admin_notes').select('*').eq('request_id', request.id).order('created_at', { ascending: false }),
    ])
    setOffers(offerRows || [])
    setNotes(noteRows || [])
    setStatus(request.status)
  }

  async function changeStatus(newStatus) {
    setStatus(newStatus)
    const { error } = await supabase.from('buyer_requests').update({ status: newStatus }).eq('id', request.id)
    if (error) { toast('حصل خطأ أثناء تحديث الحالة.'); return }
    toast(`تم تحديث حالة الطلب إلى: ${STATUS_LABEL[newStatus]}`)
    onChanged()
  }

  async function addNote() {
    const text = noteText.trim()
    if (!text) return
    const { error } = await supabase.from('admin_notes').insert({ request_id: request.id, note: text })
    if (error) { toast('حصل خطأ أثناء إضافة الملاحظة.'); return }
    setNoteText('')
    load()
  }

  async function viewImages(paths) {
    // Images live in a private bucket (see supabase/policies-storage.sql) —
    // only an authenticated admin session can mint a signed URL for them,
    // and each link expires in an hour.
    const { data, error } = await supabase.storage.from('offer-images').createSignedUrls(paths, 3600)
    if (error) { toast('حصل خطأ أثناء فتح الصور.'); return }
    data.forEach((f) => { if (f.signedUrl) window.open(f.signedUrl, '_blank', 'noopener') })
  }

  async function changeOfferStatus(offerId, newStatus) {
    const { error } = await supabase.from('seller_offers').update({ status: newStatus }).eq('id', offerId)
    if (error) { toast('حصل خطأ أثناء تحديث حالة العرض.'); return }
    setOffers((prev) => prev.map((o) => o.id === offerId ? { ...o, status: newStatus } : o))
    toast('تم تحديث حالة العرض.')
  }

  return (
    <div className="overlay" onClick={(e) => { if (e.target === e.currentTarget) onClose() }}>
      <div className="drawer">
        <div className="drawer-head">
          <h2>{request.request_code} — {request.brand} {request.model}</h2>
          <button className="drawer-close" onClick={onClose}>×</button>
        </div>
        <div className="drawer-body">

          <div className="detail-block">
            <h3>حالة الطلب</h3>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
              <span className={`badge ${STATUS_BADGE_CLASS[status]}`}>{STATUS_LABEL[status]}</span>
              <select className="status-select" value={status} onChange={(e) => changeStatus(e.target.value)}>
                {Object.keys(STATUS_LABEL).map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}
              </select>
            </div>
          </div>

          <div className="detail-block">
            <h3>بيانات المشتري</h3>
            <div className="kv-grid">
              <KV k="الاسم" v={request.buyer_name} />
              <KV k="الهاتف" v={request.buyer_phone} />
              <KV k="المحافظة" v={request.governorate} />
              <KV k="المنطقة" v={request.city} />
            </div>
          </div>

          <div className="detail-block">
            <h3>مواصفات السيارة المطلوبة</h3>
            <div className="kv-grid">
              <KV k="الماركة والموديل" v={`${request.brand} ${request.model}`} />
              <KV k="السنة" v={`${request.year_from} - ${request.year_to}`} />
              <KV k="الميزانية" v={`${money(request.budget_min)} - ${money(request.budget_max)} جنيه`} />
              <KV k="أقصى عداد" v={`${money(request.max_km)} كم`} />
              <KV k="ناقل الحركة" v={request.transmission} />
              <KV k="الوقود" v={request.fuel} />
              <KV k="الحالة" v={request.condition} />
            </div>
            {request.extra_notes ? <p style={{ marginTop: 12, fontSize: 13.5, color: 'var(--gray)' }}>{request.extra_notes}</p> : null}
          </div>

          <div className="detail-block">
            <h3>ملاحظات Admin (داخلية)</h3>
            <div>
              {notes.length ? notes.map((n) => (
                <div className="note-item" key={n.id}>
                  {n.note}
                  <div className="d">{formatDateTime(n.created_at)}</div>
                </div>
              )) : <p style={{ fontSize: 13, color: 'var(--gray-light)' }}>لا توجد ملاحظات بعد.</p>}
            </div>
            <div className="add-note-row">
              <input type="text" placeholder="اكتب ملاحظة... مثال: كلمت العميل" value={noteText}
                onChange={(e) => setNoteText(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addNote() } }} />
              <button className="btn btn-navy btn-sm" onClick={addNote}>إضافة</button>
            </div>
          </div>

          <div className="detail-block" style={{ marginBottom: 0 }}>
            <h3>العروض ({offers.length})</h3>
            {offers.length ? offers.map((o) => (
              <div className="offer-item" key={o.id}>
                <div className="offer-item-top">
                  <div>
                    <div className="oid">{o.offer_code}</div>
                    <div className="car">{o.brand} {o.model} — {o.year}</div>
                  </div>
                  <select className="status-select offer-status-select" value={o.status}
                    onChange={(e) => changeOfferStatus(o.id, e.target.value)}>
                    {Object.keys(OFFER_STATUS_LABEL).map((s) => <option key={s} value={s}>{OFFER_STATUS_LABEL[s]}</option>)}
                  </select>
                </div>
                <div className="kv-grid">
                  <KV k="البائع" v={`${o.seller_name} (${o.seller_type})`} />
                  <KV k="الهاتف" v={o.seller_phone} />
                  <KV k="السعر" v={`${money(o.price)} جنيه`} />
                  <KV k="الكيلومترات" v={`${money(o.km)} كم`} />
                  <KV k="ناقل الحركة" v={o.transmission} />
                  <KV k="الوقود" v={o.fuel} />
                </div>
                {o.description ? <p style={{ marginTop: 10, fontSize: 13, color: 'var(--gray)' }}>{o.description}</p> : null}
                {o.images && o.images.length ? (
                  <div style={{ marginTop: 8 }}>
                    <span className="icon-link" onClick={() => viewImages(o.images)}>
                      عرض الصور المرفقة ({o.images.length})
                    </span>
                  </div>
                ) : null}
              </div>
            )) : <p style={{ fontSize: 13, color: 'var(--gray-light)' }}>لا توجد عروض على هذا الطلب بعد.</p>}
          </div>

        </div>
      </div>
    </div>
  )
}

function KV({ k, v }) {
  return (
    <div className="kv">
      <div className="k">{k}</div>
      <div className="v">{v}</div>
    </div>
  )
}
