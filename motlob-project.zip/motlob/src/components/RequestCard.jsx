import { Link } from 'react-router-dom'
import StatusBadge from './StatusBadge'
import { money } from '../lib/format'

// `request` here is a row from the public_requests view (or the full table,
// when rendered inside the admin dashboard) — it never contains buyer_phone
// or buyer_name when it came from the public view.
export default function RequestCard({ request, showOfferButton = true }) {
  const r = request
  return (
    <div className="req-card">
      <div className="req-card-top">
        <div>
          <div className="rid">{r.request_code}</div>
          <div className="car-name">{r.brand} {r.model}</div>
        </div>
        <StatusBadge status={r.status} />
      </div>
      <div className="spec-list">
        <div><div className="k">السنة</div><div className="v">{r.year_from} - {r.year_to}</div></div>
        <div><div className="k">الميزانية</div><div className="v">{money(r.budget_min)} - {money(r.budget_max)} جنيه</div></div>
        <div><div className="k">أقصى عداد</div><div className="v">{money(r.max_km)} كم</div></div>
        <div><div className="k">المحافظة</div><div className="v">{r.governorate}</div></div>
        <div><div className="k">الفتيس</div><div className="v">{r.transmission}</div></div>
        <div><div className="k">الوقود</div><div className="v">{r.fuel}</div></div>
      </div>
      {r.extra_notes ? <p className="notes-mini">{r.extra_notes}</p> : null}
      {showOfferButton ? (
        <Link className="btn btn-primary btn-sm" to={`/offer/${r.id}`}>قدّم عرضك</Link>
      ) : null}
    </div>
  )
}
