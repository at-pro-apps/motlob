import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { HashRouter } from 'react-router-dom'
import App from './App.jsx'
import './index.css'
import { AdminAuthProvider } from './context/AdminAuthContext'
import { ToastProvider } from './context/ToastContext'

// HashRouter is used on purpose: GitHub Pages serves static files with no
// server-side rewrites, so a BrowserRouter route like /requests would 404 on
// a hard refresh or direct link. Hash routes (#/requests) always resolve to
// index.html first, then React Router takes over — no extra server config,
// no 404.html workaround needed.
createRoot(document.getElementById('root')).render(
  <StrictMode>
    <HashRouter>
      <ToastProvider>
        <AdminAuthProvider>
          <App />
        </AdminAuthProvider>
      </ToastProvider>
    </HashRouter>
  </StrictMode>,
)
