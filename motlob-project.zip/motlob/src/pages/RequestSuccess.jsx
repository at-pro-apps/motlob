import { Link, Navigate, useLocation } from 'react-router-dom'

export default function RequestSuccess() {
  const { state } = useLocation()
  if (!state?.code) return <Navigate to="/new-request" replace />

  return (
    <main>
      <section>
        <div className="wrap">
          <div className="success-shell">
            <div className="success-icon">✓</div>
            <h2>تم استلام طلبك بنجاح</h2>
            <div className="id-badge">{state.code}</div>
            <p className="msg">سيتم مراجعة طلبك ورفعه على الموقع خلال مدة تصل إلى يومين.</p>
            <p className="msg">بعد نشر الطلب، سيبدأ أصحاب السيارات والتجار في تقديم عروضهم، وسنتواصل معك عند وجود عرض مناسب.</p>
            <div className="keep-note">احتفظ برقم طلبك لمتابعة طلبك: <strong>{state.code}</strong></div>
            <Link className="btn btn-navy" to="/">العودة للرئيسية</Link>
          </div>
        </div>
      </section>
    </main>
  )
}
