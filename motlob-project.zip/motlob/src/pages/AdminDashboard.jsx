import { useEffect, useMemo, useState } from 'react'
import { supabase } from '../lib/supabaseClient'
import { useAdminAuth } from '../context/AdminAuthContext'
import { useToast } from '../context/ToastContext'
import { STATUS_LABEL, STATUS_BADGE_CLASS } from '../lib/constants'
import { money, formatDate } from '../lib/format'
import RequestDrawer from '../components/RequestDrawer'
import { Link } from 'react-router-dom'

export default function AdminDashboard() {
  const { signOut } = useAdminAuth()
  const toast = useToast()
  const [requests, setRequests] = useState([])
  const [offerCounts, setOfferCounts] = useState({})
  const [loading, setLoading] = useState(true)
  const [openId, setOpenId] = useState(null)
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [govFilter, setGovFilter] = useState('')
  const [updatedAt, setUpdatedAt] = useState(null)

  async function load() {
    setLoading(true)
    const [{ data: reqRows, error: reqErr }, { data: offRows, error: offErr }] = await Promise.all([
      supabase.from('buyer_requests').select('*').order('created_at', { ascending: false }),
      supabase.from('seller_offers').select('id, request_id'),
    ])
    if (reqErr) console.error(reqErr)
    if (offErr) console.error(offErr)
    setRequests(reqRows || [])
    const counts = {}
    ;(offRows || []).forEach((o) => { counts[o.request_id] = (counts[o.request_id] || 0) + 1 })
    setOfferCounts(counts)
    setUpdatedAt(new Date())
    setLoading(false)
  }

  useEffect(() => { load() }, [])

  const stats = useMemo(() => {
    const c = { total: requests.length, NEW: 0, UNDER_REVIEW: 0, PUBLISHED: 0, HAS_OFFERS: 0, COMPLETED: 0, REJECTED: 0 }
    requests.forEach((r) => { if (c[r.status] !== undefined) c[r.status]++ })
    return c
  }, [requests])

  const filtered = useMemo(() => {
    let list = requests
    if (statusFilter) list = list.filter((r) => r.status === statusFilter)
    if (govFilter) list = list.filter((r) => r.governorate.toLowerCase().includes(govFilter.toLowerCase()))
    if (search) {
      const q = search.toLowerCase()
      list = list.filter((r) =>
        r.request_code.toLowerCase().includes(q) ||
        r.buyer_name.toLowerCase().includes(q) ||
        r.buyer_phone.includes(q) ||
        r.brand.toLowerCase().includes(q) ||
        r.model.toLowerCase().includes(q)
      )
    }
    return list
  }, [requests, search, statusFilter, govFilter])

  async function publish(id) {
    const { error } = await supabase.from('buyer_requests').update({ status: 'PUBLISHED' }).eq('id', id)
    if (error) { toast('حصل خطأ.'); return }
    toast('تم نشر الطلب.')
    load()
  }
  async function reject(id) {
    const { error } = await supabase.from('buyer_requests').update({ status: 'REJECTED' }).eq('id', id)
    if (error) { toast('حصل خطأ.'); return }
    toast('تم رفض الطلب.')
    load()
  }
  async function remove(id, code) {
    if (!confirm(`هل أنت متأكد من حذف الطلب ${code}؟ سيتم حذف كل العروض المرتبطة به أيضًا.`)) return
    const { error } = await supabase.from('buyer_requests').delete().eq('id', id)
    if (error) { toast('حصل خطأ أثناء الحذف.'); return }
    toast('تم حذف الطلب.')
    load()
  }

  const openRequest = requests.find((r) => r.id === openId)

  return (
    <main>
      <div className="admin-shell">
        <aside className="admin-side">
          <div className="brand-row"><img src="/assets/motlob-logo.jpg" alt="Motlob" /></div>
          <nav className="admin-nav">
            <a className="active" href="#">نظرة عامة</a>
            <Link to="/">مشاهدة الموقع</Link>
          </nav>
          <div className="logout">
            <button className="btn btn-outline btn-sm btn-block" onClick={signOut}>تسجيل الخروج</button>
          </div>
        </aside>

        <div className="admin-main">
          <div className="admin-topbar">
            <h1>لوحة تحكم الطلبات</h1>
            <span className="count-tag">
              {updatedAt ? `آخر تحديث: ${updatedAt.toLocaleTimeString('ar-EG')}` : ''}
            </span>
          </div>

          <div className="stat-grid">
            <Stat n={stats.total} l="إجمالي الطلبات" />
            <Stat n={stats.NEW} l="طلبات جديدة" />
            <Stat n={stats.UNDER_REVIEW} l="قيد المراجعة" />
            <Stat n={stats.PUBLISHED} l="منشورة" />
            <Stat n={stats.HAS_OFFERS} l="بها عروض" />
            <Stat n={stats.COMPLETED} l="مكتملة" />
            <Stat n={stats.REJECTED} l="مرفوضة" />
          </div>

          <div className="admin-toolbar">
            <div className="search-box">
              <input type="text" placeholder="دور برقم الطلب، اسم العميل، رقم الهاتف، الماركة..."
                value={search} onChange={(e) => setSearch(e.target.value)} />
            </div>
            <div className="toolbar-filters">
              <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
                <option value="">كل الحالات</option>
                {Object.keys(STATUS_LABEL).map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}
              </select>
              <input type="text" placeholder="المحافظة" value={govFilter} onChange={(e) => setGovFilter(e.target.value)} />
            </div>
          </div>

          <div style={{ overflowX: 'auto' }}>
            <table className="admin-table">
              <thead>
                <tr>
                  <th>رقم الطلب</th><th>العميل</th><th>السيارة</th><th>الميزانية</th>
                  <th>المحافظة</th><th>الحالة</th><th>التاريخ</th><th>العروض</th><th>إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {loading ? (
                  <tr><td colSpan={9} style={{ textAlign: 'center', padding: 40, color: 'var(--gray-light)' }}>جارٍ التحميل...</td></tr>
                ) : filtered.length ? filtered.map((r) => (
                  <tr key={r.id}>
                    <td className="mono">{r.request_code}</td>
                    <td>{r.buyer_name}</td>
                    <td>{r.brand} {r.model}</td>
                    <td>{money(r.budget_min)}-{money(r.budget_max)}</td>
                    <td>{r.governorate}</td>
                    <td><span className={`badge ${STATUS_BADGE_CLASS[r.status]}`}>{STATUS_LABEL[r.status]}</span></td>
                    <td>{formatDate(r.created_at)}</td>
                    <td>{offerCounts[r.id] || 0}</td>
                    <td>
                      <div className="row-actions">
                        <span className="icon-link" onClick={() => setOpenId(r.id)}>فتح</span>
                        {['NEW', 'UNDER_REVIEW'].includes(r.status) && (
                          <>
                            {' · '}<span className="icon-link" onClick={() => publish(r.id)}>نشر</span>
                            {' · '}<span className="icon-link" style={{ color: 'var(--red)' }} onClick={() => reject(r.id)}>رفض</span>
                          </>
                        )}
                        {' · '}<span className="icon-link" style={{ color: 'var(--gray-light)' }} onClick={() => remove(r.id, r.request_code)}>حذف</span>
                      </div>
                    </td>
                  </tr>
                )) : (
                  <tr><td colSpan={9} style={{ textAlign: 'center', padding: 40, color: 'var(--gray-light)' }}>لا توجد طلبات مطابقة</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {openRequest ? (
        <RequestDrawer request={openRequest} onClose={() => setOpenId(null)} onChanged={load} />
      ) : null}
    </main>
  )
}

function Stat({ n, l }) {
  return (
    <div className="stat-card">
      <div className="n">{n}</div>
      <div className="l">{l}</div>
    </div>
  )
}
