import { Link, Navigate, useLocation } from 'react-router-dom'

export default function OfferSuccess() {
  const { state } = useLocation()
  if (!state?.code) return <Navigate to="/requests" replace />

  return (
    <main>
      <section>
        <div className="wrap">
          <div className="success-shell">
            <div className="success-icon">✓</div>
            <h2>تم استلام عرضك بنجاح</h2>
            <div className="id-badge">{state.code}</div>
            <p className="msg">سيتم مراجعة العرض والتواصل معك إذا كان مناسبًا للطلب.</p>
            <Link className="btn btn-navy" to="/requests">العودة لصفحة الطلبات</Link>
          </div>
        </div>
      </section>
    </main>
  )
}
