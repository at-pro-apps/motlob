import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabaseClient'
import RequestCard from '../components/RequestCard'

export default function Home() {
  const [latest, setLatest] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    let alive = true
    supabase
      .from('public_requests')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(3)
      .then(({ data, error }) => {
        if (!alive) return
        if (error) console.error(error)
        setLatest(data || [])
        setLoading(false)
      })
    return () => { alive = false }
  }, [])

  return (
    <main>
      <section className="hero">
        <div className="hero-stripes"><div className="s1 stripes"></div></div>
        <div className="wrap hero-inner">
          <div>
            <span className="eyebrow-tag"><span className="dot"></span> منصة طلب السيارات الأولى في مصر</span>
            <h1>مش لاقي العربية اللي عايزها؟</h1>
            <p className="lead">اطلبها، وخلي أصحاب العربيات والتجار يقدموا لك عروضهم. أنت تطلب العربية، وأصحابها يقدموا لك عروضهم.</p>
            <div className="hero-actions">
              <Link className="btn btn-primary" to="/new-request">اطلب عربيتك</Link>
              <Link className="btn btn-outline-white" to="/requests">شوف الطلبات</Link>
            </div>
          </div>
          <div className="hero-visual">
            <p className="tag-line">اطلب عربيتك، وخلي العروض تيجيلك.</p>
            <div className="flow-mini">
              <div className="step"><span className="num">1</span><span className="txt">اطلب العربية</span></div>
              <div className="step"><span className="num">2</span><span className="txt">نراجع طلبك</span></div>
              <div className="step"><span className="num">3</span><span className="txt">يظهر طلبك على الموقع</span></div>
              <div className="step"><span className="num">4</span><span className="txt">أصحاب العربيات يقدموا عروضهم</span></div>
              <div className="step"><span className="num">5</span><span className="txt">نراجع العروض ونتواصل معك</span></div>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="wrap">
          <div className="section-head">
            <p className="section-tag">طريقة العمل</p>
            <h2>خمس خطوات، وتلاقي عربيتك</h2>
            <p>كل طلب بيتراجع يدويًا قبل ما ينزل على الموقع، وكل عرض بيتراجع قبل ما يوصلك.</p>
          </div>
          <div className="how-grid">
            <div className="how-card"><span className="num">01</span><h3>اطلب العربية</h3><p>احكيلنا مواصفات العربية اللي بتدور عليها وميزانيتك.</p><span className="how-arrow">‹</span></div>
            <div className="how-card"><span className="num">02</span><h3>نراجع طلبك</h3><p>فريق Motlob يراجع بيانات الطلب خلال يومين.</p><span className="how-arrow">‹</span></div>
            <div className="how-card"><span className="num">03</span><h3>يظهر طلبك</h3><p>الطلب بينشر على الموقع بدون بياناتك الشخصية.</p><span className="how-arrow">‹</span></div>
            <div className="how-card"><span className="num">04</span><h3>تيجي العروض</h3><p>أصحاب العربيات والتجار يقدموا عروضهم على طلبك.</p><span className="how-arrow">‹</span></div>
            <div className="how-card"><span className="num">05</span><h3>نتواصل معك</h3><p>نراجع العروض المناسبة وننسق بينك وبين البائع.</p></div>
          </div>
        </div>
      </section>

      <section className="why-section">
        <div className="wrap">
          <div className="section-head">
            <p className="section-tag">ليه Motlob</p>
            <h2>مختلفة عن مواقع الإعلانات التقليدية</h2>
          </div>
          <div className="why-grid">
            <div className="why-card">
              <div className="why-icon">◧</div>
              <h3>وقتك محسوب</h3>
              <p>مش هتدور بين آلاف الإعلانات، العروض هي اللي هتيجيلك.</p>
            </div>
            <div className="why-card">
              <div className="why-icon">◨</div>
              <h3>بياناتك محمية</h3>
              <p>رقمك مش بيوصل لحد غير Admin، والتواصل بيتم يدويًا معاك.</p>
            </div>
            <div className="why-card">
              <div className="why-icon">◫</div>
              <h3>مراجعة بشرية</h3>
              <p>كل طلب وكل عرض بيتراجع قبل ما ينشر أو يوصلك.</p>
            </div>
            <div className="why-card">
              <div className="why-icon">◩</div>
              <h3>واجهة نظيفة</h3>
              <p>تصميم بسيط ومباشر، من غير زحمة إعلانات.</p>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="wrap">
          <div className="latest-head">
            <div className="section-head">
              <p className="section-tag">أحدث الطلبات</p>
              <h2>عربيات مطلوبة حاليًا</h2>
            </div>
            <Link className="btn btn-outline btn-sm" to="/requests">شوف كل الطلبات</Link>
          </div>
          <div className="req-grid">
            {loading ? null : latest.length ? (
              latest.map((r) => <RequestCard key={r.id} request={r} />)
            ) : (
              <div className="empty-state" style={{ gridColumn: '1/-1' }}>
                <div className="ei">🚗</div>
                <h3>مفيش طلبات منشورة لسه</h3>
                <p>كن أول من يطلب عربيته.</p>
                <Link className="btn btn-primary btn-sm" to="/new-request">اطلب عربيتك</Link>
              </div>
            )}
          </div>
        </div>
      </section>

      <section style={{ paddingTop: 0 }}>
        <div className="wrap">
          <div className="cta-band">
            <div>
              <h2>عندك عربية للبيع؟</h2>
              <p>شوف الطلبات المنشورة وقدّم عرضك على العربية اللي تناسبك.</p>
            </div>
            <div className="cta-actions">
              <Link className="btn btn-primary" to="/requests">عندي عربية مطلوبة</Link>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
