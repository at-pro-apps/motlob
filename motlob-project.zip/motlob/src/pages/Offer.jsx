import { useEffect, useState } from 'react'
import { Link, useNavigate, useParams } from 'react-router-dom'
import { supabase } from '../lib/supabaseClient'
import { GOVERNORATES } from '../lib/constants'
import { isValidEgyptianPhone, money } from '../lib/format'

const EMPTY = {
  sName: '', sPhone: '', sType: '', sDealerName: '', sGov: '',
  oBrand: '', oModel: '', oYear: '', oKm: '', oPrice: '',
  oTrans: '', oFuel: '', oCondition: '', oDesc: '', oNotes: '',
}

export default function Offer() {
  const { requestId } = useParams()
  const navigate = useNavigate()
  const [request, setRequest] = useState(null)
  const [notFound, setNotFound] = useState(false)
  const [form, setForm] = useState(EMPTY)
  const [errors, setErrors] = useState({})
  const [images, setImages] = useState([])
  const [submitting, setSubmitting] = useState(false)

  useEffect(() => {
    let alive = true
    supabase
      .from('public_requests')
      .select('*')
      .eq('id', requestId)
      .maybeSingle()
      .then(({ data, error }) => {
        if (!alive) return
        if (error || !data) { setNotFound(true); return }
        setRequest(data)
      })
    return () => { alive = false }
  }, [requestId])

  function set(field, value) { setForm((f) => ({ ...f, [field]: value })) }

  function onFilesChosen(e) {
    setImages((prev) => [...prev, ...Array.from(e.target.files)])
    e.target.value = ''
  }
  function removeImage(idx) {
    setImages((prev) => prev.filter((_, i) => i !== idx))
  }

  function validate() {
    const e = {}
    if (form.sName.trim().length < 3) e.sName = 'من فضلك اكتب اسمك.'
    if (!isValidEgyptianPhone(form.sPhone)) e.sPhone = 'رقم الهاتف غير صحيح.'
    if (!form.sType) e.sType = 'من فضلك اختر نوع البائع.'
    if (!form.sGov) e.sGov = 'من فضلك اختر المحافظة.'
    if (form.oBrand.trim().length < 2) e.oBrand = 'من فضلك اكتب الماركة.'
    if (form.oModel.trim().length < 1) e.oModel = 'من فضلك اكتب الموديل.'
    const y = parseInt(form.oYear, 10)
    if (!(y >= 1980 && y <= 2026)) e.oYear = 'أدخل سنة صحيحة.'
    if (!(parseInt(form.oKm, 10) >= 0)) e.oKm = 'أدخل رقمًا صحيحًا.'
    if (!(parseInt(form.oPrice, 10) >= 0)) e.oPrice = 'أدخل رقمًا صحيحًا.'
    if (!form.oTrans) e.oTrans = 'من فضلك اختر ناقل الحركة.'
    if (!form.oFuel) e.oFuel = 'من فضلك اختر نوع الوقود.'
    if (!form.oCondition) e.oCondition = 'من فضلك اختر حالة السيارة.'
    if (form.oDesc.trim().length < 5) e.oDesc = 'من فضلك اكتب وصفًا للسيارة.'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  async function handleSubmit(ev) {
    ev.preventDefault()
    if (!request) return
    if (!validate()) return
    setSubmitting(true)

    // 1) Insert the offer via the submit_seller_offer() RPC (SECURITY
    // DEFINER) — see supabase/schema.sql. It also re-checks server-side
    // that the request is still open for offers.
    const { data: rows, error } = await supabase.rpc('submit_seller_offer', {
      p_request_id: request.id,
      p_seller_name: form.sName.trim(),
      p_seller_phone: form.sPhone.trim(),
      p_seller_type: form.sType,
      p_dealer_name: form.sDealerName.trim(),
      p_seller_governorate: form.sGov,
      p_brand: form.oBrand.trim(),
      p_model: form.oModel.trim(),
      p_year: parseInt(form.oYear, 10),
      p_km: parseInt(form.oKm, 10),
      p_price: parseInt(form.oPrice, 10),
      p_transmission: form.oTrans,
      p_fuel: form.oFuel,
      p_condition: form.oCondition,
      p_description: form.oDesc.trim(),
      p_notes: form.oNotes.trim(),
    })

    if (error || !rows?.length) {
      console.error(error)
      setErrors({ submit: 'حصل خطأ أثناء إرسال العرض، من فضلك حاول مرة أخرى.' })
      setSubmitting(false)
      return
    }

    const offerRow = rows[0]

    // 2) Upload any attached images to the private `offer-images` bucket,
    // then attach their paths via attach_offer_images() (SECURITY DEFINER —
    // this is the only way to write to seller_offers.images from the
    // client). Storage policies let anon upload but only admins read —
    // see supabase/policies-storage.sql.
    if (images.length) {
      const paths = []
      for (const file of images) {
        const path = `${offerRow.id}/${Date.now()}-${file.name}`
        const { error: upErr } = await supabase.storage.from('offer-images').upload(path, file)
        if (!upErr) paths.push(path)
      }
      if (paths.length) {
        await supabase.rpc('attach_offer_images', { p_offer_id: offerRow.id, p_paths: paths })
      }
    }

    setSubmitting(false)
    navigate('/offer-success', { state: { code: offerRow.offer_code } })
  }

  if (notFound) {
    return (
      <main>
        <section>
          <div className="wrap">
            <div className="empty-state" style={{ maxWidth: 480, margin: '60px auto' }}>
              <div className="ei">🚫</div>
              <h3>الطلب غير متاح</h3>
              <p>هذا الطلب غير موجود أو لم يعد منشورًا.</p>
              <Link className="btn btn-primary btn-sm" to="/requests">شوف الطلبات المتاحة</Link>
            </div>
          </div>
        </section>
      </main>
    )
  }

  return (
    <main>
      <div className="page-header">
        <div className="wrap">
          <p className="breadcrumb"><Link to="/">Motlob</Link> / <Link to="/requests">العربيات المطلوبة</Link> / قدّم عرضك</p>
          <h1>قدّم عرضك</h1>
          <p>راجع تفاصيل الطلب وقدّم عرضك، وهنراجعه ونتواصل معك لو مناسب.</p>
        </div>
      </div>
      <section>
        <div className="wrap">
          <div className="form-shell">
            <div className="ctx-card">
              {request ? (
                <>
                  <div>
                    <div className="rid">{request.request_code}</div>
                    <div className="car">مطلوب: {request.brand} {request.model}</div>
                    <div className="specs">
                      {request.year_from}-{request.year_to} · {money(request.budget_min)}-{money(request.budget_max)} جنيه · حتى {money(request.max_km)} كم · {request.governorate}
                    </div>
                  </div>
                  <Link className="btn btn-outline-white btn-sm" to="/requests">تغيير الطلب</Link>
                </>
              ) : (
                <div><div className="rid">جارٍ تحميل بيانات الطلب...</div></div>
              )}
            </div>

            {request ? (
              <form className="card" onSubmit={handleSubmit} noValidate>
                <p className="form-section-title">بياناتك</p>
                <div className="grid2">
                  <Field label="الاسم" required error={errors.sName}>
                    <input type="text" placeholder="اسمك بالكامل" value={form.sName} onChange={(e) => set('sName', e.target.value)} />
                  </Field>
                  <Field label="رقم الهاتف" required error={errors.sPhone}>
                    <input type="tel" placeholder="01xxxxxxxxx" value={form.sPhone} onChange={(e) => set('sPhone', e.target.value)} />
                  </Field>
                </div>
                <SegField label="نوع البائع" required error={errors.sType} name="sType"
                  options={['مالك سيارة', 'تاجر', 'معرض']} value={form.sType} onChange={(v) => set('sType', v)} />
                <div className="grid2">
                  <Field label="اسم المعرض (إن وجد)">
                    <input type="text" placeholder="اسم المعرض" value={form.sDealerName} onChange={(e) => set('sDealerName', e.target.value)} />
                  </Field>
                  <Field label="المحافظة" required error={errors.sGov}>
                    <select value={form.sGov} onChange={(e) => set('sGov', e.target.value)}>
                      <option value="">اختر المحافظة</option>
                      {GOVERNORATES.map((g) => <option key={g} value={g}>{g}</option>)}
                    </select>
                  </Field>
                </div>

                <p className="form-section-title">السيارة المعروضة</p>
                <div className="grid2">
                  <Field label="الماركة" required error={errors.oBrand}>
                    <input type="text" placeholder="مثال: Toyota" value={form.oBrand} onChange={(e) => set('oBrand', e.target.value)} />
                  </Field>
                  <Field label="الموديل" required error={errors.oModel}>
                    <input type="text" placeholder="مثال: Corolla" value={form.oModel} onChange={(e) => set('oModel', e.target.value)} />
                  </Field>
                  <Field label="سنة السيارة" required error={errors.oYear}>
                    <input type="number" min="1980" max="2026" placeholder="2019" value={form.oYear} onChange={(e) => set('oYear', e.target.value)} />
                  </Field>
                  <Field label="عدد الكيلومترات" required error={errors.oKm}>
                    <input type="number" min="0" placeholder="80000" value={form.oKm} onChange={(e) => set('oKm', e.target.value)} />
                  </Field>
                  <Field label="السعر المطلوب (جنيه)" required error={errors.oPrice}>
                    <input type="number" min="0" placeholder="750000" value={form.oPrice} onChange={(e) => set('oPrice', e.target.value)} />
                  </Field>
                </div>

                <SegField label="ناقل الحركة" required error={errors.oTrans} name="oTrans"
                  options={['أوتوماتيك', 'مانيوال']} value={form.oTrans} onChange={(v) => set('oTrans', v)} />
                <SegField label="الوقود" required error={errors.oFuel} name="oFuel"
                  options={['بنزين', 'ديزل', 'غاز', 'Hybrid']} value={form.oFuel} onChange={(v) => set('oFuel', v)} />
                <SegField label="حالة السيارة" required error={errors.oCondition} name="oCondition"
                  options={['مستعملة', 'جديدة']} value={form.oCondition} onChange={(v) => set('oCondition', v)} />

                <Field label="وصف السيارة" required error={errors.oDesc}>
                  <textarea placeholder="اكتب وصفًا مختصرًا وصادقًا لحالة السيارة" value={form.oDesc} onChange={(e) => set('oDesc', e.target.value)} />
                </Field>
                <div className="field">
                  <label>أي ملاحظات إضافية</label>
                  <textarea placeholder="اختياري" value={form.oNotes} onChange={(e) => set('oNotes', e.target.value)} />
                </div>

                <div className="field">
                  <label>صور السيارة</label>
                  <label className="file-drop">
                    اضغط هنا لإرفاق صور السيارة (JPG / PNG)
                    <input type="file" accept="image/*" multiple onChange={onFilesChosen} />
                  </label>
                  <div className="file-list">
                    {images.map((f, i) => (
                      <span className="file-chip" key={i}>
                        {f.name}
                        <button type="button" onClick={() => removeImage(i)} aria-label="حذف">×</button>
                      </span>
                    ))}
                  </div>
                  <p className="hint">الصور تُستخدم للمراجعة فقط ولن تُنشر بدون موافقتك.</p>
                </div>

                {errors.submit ? <p className="err" style={{ display: 'block', marginBottom: 12 }}>{errors.submit}</p> : null}

                <div className="form-foot">
                  <button type="submit" className="btn btn-primary" disabled={submitting}>
                    {submitting ? 'جارٍ الإرسال...' : 'إرسال العرض'}
                  </button>
                </div>
              </form>
            ) : null}
          </div>
        </div>
      </section>
    </main>
  )
}

function Field({ label, required, error, children }) {
  return (
    <div className={`field${error ? ' has-error' : ''}`}>
      <label>{label} {required ? <span className="req">*</span> : null}</label>
      {children}
      {error ? <p className="err" style={{ display: 'block' }}>{error}</p> : null}
    </div>
  )
}

function SegField({ label, required, error, options, value, onChange, name }) {
  return (
    <div className={`field${error ? ' has-error' : ''}`}>
      <label>{label} {required ? <span className="req">*</span> : null}</label>
      <div className="seg">
        {options.map((opt) => {
          const id = `${name}-${opt}`
          return (
            <span key={opt} style={{ position: 'relative', flex: 1, minWidth: 90 }}>
              <input type="radio" name={name} id={id} checked={value === opt} onChange={() => onChange(opt)} style={{ position: 'absolute', opacity: 0 }} />
              <label htmlFor={id} className={value === opt ? 'checked' : ''} style={{ display: 'block' }}>{opt}</label>
            </span>
          )
        })}
      </div>
      {error ? <p className="err" style={{ display: 'block' }}>{error}</p> : null}
    </div>
  )
}
