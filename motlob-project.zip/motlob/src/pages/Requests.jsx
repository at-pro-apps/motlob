import { useEffect, useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../lib/supabaseClient'
import { GOVERNORATES } from '../lib/constants'
import RequestCard from '../components/RequestCard'

export default function Requests() {
  const [all, setAll] = useState([])
  const [loading, setLoading] = useState(true)
  const [filters, setFilters] = useState({
    brand: '', model: '', governorate: '', transmission: '', fuel: '', budget: '', year: '', q: '',
  })

  useEffect(() => {
    let alive = true
    supabase
      .from('public_requests')
      .select('*')
      .order('created_at', { ascending: false })
      .then(({ data, error }) => {
        if (!alive) return
        if (error) console.error(error)
        setAll(data || [])
        setLoading(false)
      })
    return () => { alive = false }
  }, [])

  function setF(k, v) { setFilters((f) => ({ ...f, [k]: v })) }
  function clearFilters() {
    setFilters({ brand: '', model: '', governorate: '', transmission: '', fuel: '', budget: '', year: '', q: '' })
  }

  const filtered = useMemo(() => {
    let list = all
    const { brand, model, governorate, transmission, fuel, budget, year, q } = filters
    if (brand) list = list.filter((r) => r.brand.toLowerCase().includes(brand.toLowerCase()))
    if (model) list = list.filter((r) => r.model.toLowerCase().includes(model.toLowerCase()))
    if (governorate) list = list.filter((r) => r.governorate === governorate)
    if (transmission) list = list.filter((r) => r.transmission === transmission)
    if (fuel) list = list.filter((r) => r.fuel === fuel)
    const b = parseInt(budget, 10)
    if (!isNaN(b)) list = list.filter((r) => r.budget_min <= b)
    const y = parseInt(year, 10)
    if (!isNaN(y)) list = list.filter((r) => r.year_to >= y)
    if (q) {
      const qq = q.toLowerCase()
      list = list.filter((r) =>
        r.request_code.toLowerCase().includes(qq) ||
        r.brand.toLowerCase().includes(qq) ||
        r.model.toLowerCase().includes(qq)
      )
    }
    return list
  }, [all, filters])

  return (
    <main>
      <div className="page-header">
        <div className="wrap">
          <p className="breadcrumb"><Link to="/">Motlob</Link> / العربيات المطلوبة</p>
          <h1>العربيات المطلوبة</h1>
          <p>طلبات حقيقية من مشترين، راجعناها ونشرناها. قدّم عرضك على الطلب المناسب لك.</p>
        </div>
      </div>
      <section style={{ paddingTop: 0 }}>
        <div className="wrap board">
          <aside className="filters">
            <h3>فلترة الطلبات</h3>
            <div className="field">
              <label>الماركة</label>
              <input type="text" placeholder="مثال: Toyota" value={filters.brand} onChange={(e) => setF('brand', e.target.value)} />
            </div>
            <div className="field">
              <label>الموديل</label>
              <input type="text" placeholder="مثال: Corolla" value={filters.model} onChange={(e) => setF('model', e.target.value)} />
            </div>
            <div className="field">
              <label>المحافظة</label>
              <select value={filters.governorate} onChange={(e) => setF('governorate', e.target.value)}>
                <option value="">كل المحافظات</option>
                {GOVERNORATES.map((g) => <option key={g} value={g}>{g}</option>)}
              </select>
            </div>
            <div className="field">
              <label>ناقل الحركة</label>
              <select value={filters.transmission} onChange={(e) => setF('transmission', e.target.value)}>
                <option value="">أي نوع</option>
                <option value="أوتوماتيك">أوتوماتيك</option>
                <option value="مانيوال">مانيوال</option>
              </select>
            </div>
            <div className="field">
              <label>الوقود</label>
              <select value={filters.fuel} onChange={(e) => setF('fuel', e.target.value)}>
                <option value="">أي نوع</option>
                <option value="بنزين">بنزين</option>
                <option value="ديزل">ديزل</option>
                <option value="غاز">غاز</option>
                <option value="Hybrid">Hybrid</option>
              </select>
            </div>
            <div className="field">
              <label>أقصى ميزانية</label>
              <input type="number" placeholder="مثال: 900000" value={filters.budget} onChange={(e) => setF('budget', e.target.value)} />
            </div>
            <div className="field">
              <label>أقل موديل سنة</label>
              <input type="number" placeholder="مثال: 2017" value={filters.year} onChange={(e) => setF('year', e.target.value)} />
            </div>
            <button className="btn btn-outline btn-sm btn-block" type="button" onClick={clearFilters}>مسح الفلاتر</button>
          </aside>
          <div>
            <div className="board-top">
              <div className="search-box">
                <input type="text" placeholder="دور برقم الطلب أو الماركة أو الموديل..." value={filters.q} onChange={(e) => setF('q', e.target.value)} />
              </div>
              <span className="count-tag">{filtered.length} طلب</span>
            </div>
            <div className="req-cards">
              {loading ? null : filtered.length ? (
                filtered.map((r) => <RequestCard key={r.id} request={r} />)
              ) : (
                <div className="empty-state">
                  <div className="ei">🔍</div>
                  <h3>مفيش نتائج مطابقة</h3>
                  <p>جرّب تغيّر الفلاتر أو امسحها.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
