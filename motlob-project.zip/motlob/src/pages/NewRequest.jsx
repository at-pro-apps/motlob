import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { supabase } from '../lib/supabaseClient'
import { GOVERNORATES } from '../lib/constants'
import { isValidEgyptianPhone } from '../lib/format'

const EMPTY = {
  name: '', phone: '', governorate: '', city: '',
  brand: '', model: '', yearFrom: '', yearTo: '',
  budgetMin: '', budgetMax: '', maxKm: '',
  transmission: '', fuel: '', condition: '', extra: '', agree: false,
}

export default function NewRequest() {
  const [form, setForm] = useState(EMPTY)
  const [errors, setErrors] = useState({})
  const [submitting, setSubmitting] = useState(false)
  const navigate = useNavigate()

  function set(field, value) {
    setForm((f) => ({ ...f, [field]: value }))
  }

  function validate() {
    const e = {}
    if (form.name.trim().length < 3) e.name = 'من فضلك اكتب اسمك بالكامل.'
    if (!isValidEgyptianPhone(form.phone)) e.phone = 'رقم الهاتف غير صحيح.'
    if (!form.governorate) e.governorate = 'من فضلك اختر المحافظة.'
    if (form.city.trim().length < 2) e.city = 'من فضلك اكتب المنطقة أو المدينة.'
    if (form.brand.trim().length < 2) e.brand = 'من فضلك اكتب ماركة السيارة.'
    if (form.model.trim().length < 1) e.model = 'من فضلك اكتب الموديل.'
    const yf = parseInt(form.yearFrom, 10)
    const yt = parseInt(form.yearTo, 10)
    if (!(yf >= 1980 && yf <= 2026)) e.yearFrom = 'أدخل سنة صحيحة.'
    if (!(yt >= yf)) e.yearTo = 'السنة يجب أن تكون بعد سنة "من".'
    const bmin = parseInt(form.budgetMin, 10)
    const bmax = parseInt(form.budgetMax, 10)
    if (!(bmin >= 0)) e.budgetMin = 'أدخل رقمًا صحيحًا.'
    if (!(bmax >= bmin)) e.budgetMax = 'الميزانية القصوى يجب أن تكون أكبر من الأقل.'
    if (!(parseInt(form.maxKm, 10) >= 0)) e.maxKm = 'أدخل رقمًا صحيحًا.'
    if (!form.transmission) e.transmission = 'من فضلك اختر نوع ناقل الحركة.'
    if (!form.fuel) e.fuel = 'من فضلك اختر نوع الوقود.'
    if (!form.condition) e.condition = 'من فضلك اختر حالة السيارة.'
    if (!form.agree) e.agree = 'لازم توافق على التواصل عشان نكمل طلبك.'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  async function handleSubmit(ev) {
    ev.preventDefault()
    if (!validate()) return
    setSubmitting(true)

    // Goes through the submit_buyer_request() RPC (SECURITY DEFINER), not a
    // direct table insert — see supabase/schema.sql for why. Status is
    // always forced to 'NEW' server-side regardless of what's sent here.
    // The insert itself triggers a Database Webhook that calls the
    // notify-new-request Edge Function to email the admin; the buyer never
    // sees that happen.
    const { data, error } = await supabase.rpc('submit_buyer_request', {
      p_buyer_name: form.name.trim(),
      p_buyer_phone: form.phone.trim(),
      p_governorate: form.governorate,
      p_city: form.city.trim(),
      p_brand: form.brand.trim(),
      p_model: form.model.trim(),
      p_year_from: parseInt(form.yearFrom, 10),
      p_year_to: parseInt(form.yearTo, 10),
      p_budget_min: parseInt(form.budgetMin, 10),
      p_budget_max: parseInt(form.budgetMax, 10),
      p_max_km: parseInt(form.maxKm, 10),
      p_transmission: form.transmission,
      p_fuel: form.fuel,
      p_condition: form.condition,
      p_extra_notes: form.extra.trim(),
    })

    setSubmitting(false)

    if (error) {
      console.error(error)
      setErrors({ submit: 'حصل خطأ أثناء إرسال الطلب، من فضلك حاول مرة أخرى.' })
      return
    }

    navigate('/request-success', { state: { code: data } })
  }

  return (
    <main>
      <div className="page-header">
        <div className="wrap">
          <p className="breadcrumb"><Link to="/">Motlob</Link> / اطلب عربيتك</p>
          <h1>اطلب عربيتك</h1>
          <p>احكيلنا مواصفات العربية اللي بتدور عليها، وسيبلنا الباقي.</p>
        </div>
      </div>
      <section>
        <div className="wrap">
          <div className="form-shell">
            <form className="card" onSubmit={handleSubmit} noValidate>

              <p className="form-section-title">بياناتك</p>
              <p className="form-section-sub">هنستخدمها للتواصل معاك بخصوص طلبك فقط.</p>
              <div className="grid2">
                <Field label="الاسم بالكامل" required error={errors.name}>
                  <input type="text" placeholder="مثال: أحمد محمود" value={form.name} onChange={(e) => set('name', e.target.value)} />
                </Field>
                <Field label="رقم الهاتف" required error={errors.phone}>
                  <input type="tel" placeholder="01xxxxxxxxx" value={form.phone} onChange={(e) => set('phone', e.target.value)} />
                </Field>
                <Field label="المحافظة" required error={errors.governorate}>
                  <select value={form.governorate} onChange={(e) => set('governorate', e.target.value)}>
                    <option value="">اختر المحافظة</option>
                    {GOVERNORATES.map((g) => <option key={g} value={g}>{g}</option>)}
                  </select>
                </Field>
                <Field label="المنطقة / المدينة" required error={errors.city}>
                  <input type="text" placeholder="مثال: مدينة نصر" value={form.city} onChange={(e) => set('city', e.target.value)} />
                </Field>
              </div>

              <p className="form-section-title">مواصفات العربية</p>
              <p className="form-section-sub">كل ما كانت التفاصيل أدق، كل ما كانت العروض أنسب.</p>
              <div className="grid2">
                <Field label="ماركة السيارة" required error={errors.brand}>
                  <input type="text" placeholder="مثال: Toyota" value={form.brand} onChange={(e) => set('brand', e.target.value)} />
                </Field>
                <Field label="الموديل" required error={errors.model}>
                  <input type="text" placeholder="مثال: Corolla" value={form.model} onChange={(e) => set('model', e.target.value)} />
                </Field>
                <Field label="سنة الموديل من" required error={errors.yearFrom}>
                  <input type="number" min="1980" max="2026" placeholder="2018" value={form.yearFrom} onChange={(e) => set('yearFrom', e.target.value)} />
                </Field>
                <Field label="سنة الموديل إلى" required error={errors.yearTo}>
                  <input type="number" min="1980" max="2026" placeholder="2021" value={form.yearTo} onChange={(e) => set('yearTo', e.target.value)} />
                </Field>
                <Field label="أقل ميزانية (جنيه)" required error={errors.budgetMin}>
                  <input type="number" min="0" placeholder="600000" value={form.budgetMin} onChange={(e) => set('budgetMin', e.target.value)} />
                </Field>
                <Field label="أقصى ميزانية (جنيه)" required error={errors.budgetMax}>
                  <input type="number" min="0" placeholder="800000" value={form.budgetMax} onChange={(e) => set('budgetMax', e.target.value)} />
                </Field>
                <Field label="أقصى عدد كيلومترات" required error={errors.maxKm}>
                  <input type="number" min="0" placeholder="120000" value={form.maxKm} onChange={(e) => set('maxKm', e.target.value)} />
                </Field>
              </div>

              <SegField label="نوع ناقل الحركة" required error={errors.transmission}
                options={['أوتوماتيك', 'مانيوال', 'لا يهم']} value={form.transmission}
                onChange={(v) => set('transmission', v)} name="transmission" />

              <SegField label="نوع الوقود" required error={errors.fuel}
                options={['بنزين', 'ديزل', 'غاز', 'Hybrid', 'لا يهم']} value={form.fuel}
                onChange={(v) => set('fuel', v)} name="fuel" />

              <SegField label="حالة السيارة المطلوبة" required error={errors.condition}
                options={['مستعملة', 'جديدة', 'لا يهم']} value={form.condition}
                onChange={(v) => set('condition', v)} name="condition" />

              <div className="field">
                <label>أي مواصفات أو شروط إضافية</label>
                <textarea placeholder="مثال: لونها فاتح، فبريكا أصلي، مفيش حوادث..." value={form.extra} onChange={(e) => set('extra', e.target.value)} />
              </div>

              <div className={`field${errors.agree ? ' has-error' : ''}`} style={{ marginTop: 22 }}>
                <label className="checkline">
                  <input type="checkbox" checked={form.agree} onChange={(e) => set('agree', e.target.checked)} />
                  <span>أوافق على تواصل فريق Motlob معي بخصوص هذا الطلب.</span>
                </label>
                {errors.agree ? <p className="err" style={{ display: 'block' }}>{errors.agree}</p> : null}
              </div>

              {errors.submit ? <p className="err" style={{ display: 'block', marginBottom: 12 }}>{errors.submit}</p> : null}

              <div className="form-foot">
                <button type="submit" className="btn btn-primary" disabled={submitting}>
                  {submitting ? 'جارٍ الإرسال...' : 'إرسال الطلب'}
                </button>
              </div>
            </form>
          </div>
        </div>
      </section>
    </main>
  )
}

function Field({ label, required, error, children }) {
  return (
    <div className={`field${error ? ' has-error' : ''}`}>
      <label>{label} {required ? <span className="req">*</span> : null}</label>
      {children}
      {error ? <p className="err" style={{ display: 'block' }}>{error}</p> : null}
    </div>
  )
}

function SegField({ label, required, error, options, value, onChange, name }) {
  return (
    <div className={`field${error ? ' has-error' : ''}`}>
      <label>{label} {required ? <span className="req">*</span> : null}</label>
      <div className="seg">
        {options.map((opt) => {
          const id = `${name}-${opt}`
          return (
            <span key={opt} style={{ position: 'relative', flex: 1, minWidth: 90 }}>
              <input type="radio" name={name} id={id} checked={value === opt} onChange={() => onChange(opt)} style={{ position: 'absolute', opacity: 0 }} />
              <label htmlFor={id} className={value === opt ? 'checked' : ''} style={{ display: 'block' }}>{opt}</label>
            </span>
          )
        })}
      </div>
      {error ? <p className="err" style={{ display: 'block' }}>{error}</p> : null}
    </div>
  )
}
