import { useState } from 'react'
import { useAdminAuth } from '../context/AdminAuthContext'

export default function AdminLogin() {
  const { signIn } = useAdminAuth()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const [submitting, setSubmitting] = useState(false)

  async function handleSubmit(e) {
    e.preventDefault()
    setSubmitting(true)
    setError('')
    const { error } = await signIn(email.trim(), password)
    setSubmitting(false)
    if (error) setError('البريد الإلكتروني أو كلمة المرور غير صحيحة.')
  }

  return (
    <main>
      <section>
        <div className="wrap">
          <div className="admin-login-shell">
            <div className="card">
              <div className="lock">🔒</div>
              <h2>لوحة تحكم Motlob</h2>
              <p className="sub">هذه المساحة مخصصة لإدارة الموقع فقط.</p>
              <form onSubmit={handleSubmit}>
                <div className={`field${error ? ' has-error' : ''}`} style={{ textAlign: 'right' }}>
                  <label>البريد الإلكتروني</label>
                  <input type="email" placeholder="admin@example.com" value={email}
                    onChange={(e) => setEmail(e.target.value)} autoComplete="username" />
                </div>
                <div className={`field${error ? ' has-error' : ''}`} style={{ textAlign: 'right' }}>
                  <label>كلمة المرور</label>
                  <input type="password" placeholder="••••••••" value={password}
                    onChange={(e) => setPassword(e.target.value)} autoComplete="current-password" />
                  {error ? <p className="err" style={{ display: 'block' }}>{error}</p> : null}
                </div>
                <button type="submit" className="btn btn-navy btn-block" disabled={submitting}>
                  {submitting ? 'جارٍ الدخول...' : 'دخول'}
                </button>
              </form>
              <div className="demo-note">
                الدخول هنا مصادقة حقيقية عبر Supabase Auth. لإنشاء أول حساب Admin، أضف مستخدمًا من
                Supabase Dashboard → Authentication، ثم أضف صف له في جدول <code>admins</code> — راجع README.md.
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
