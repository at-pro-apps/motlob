# Motlob (مطلوب)

منصة Reverse Marketplace لطلب السيارات في مصر. المشتري يطلب العربية اللي عايزها، الطلب بيتراجع
ويتنشر بمعرفة Admin، وبعدين أصحاب السيارات والتجار يقدموا عروضهم. لا يوجد تواصل مباشر بين
المشتري والبائع — Admin هو الوسيط الوحيد في هذه المرحلة (Admin-Managed Marketplace).

## البنية التقنية (Architecture)

هذا مشروع **Frontend ثابت (static) + Backend مُستضاف (hosted)**، مقسّم عن قصد بحيث يكون الجزء
الأمامي قابلاً للاستضافة على GitHub Pages مجانًا:

| الطبقة | التقنية | أين تعمل |
|---|---|---|
| الواجهة (UI) | React + Vite, React Router (`HashRouter`) | ثابتة، تُبنى وتُنشر على **GitHub Pages** |
| قاعدة البيانات + Auth + RLS | **Supabase** (Postgres) | مُستضافة على Supabase |
| تخزين صور العروض | Supabase Storage (bucket خاص) | مُستضاف على Supabase |
| إشعارات البريد للـAdmin | Supabase Edge Functions + Resend | مُستضافة على Supabase، تُستدعى عبر Database Webhooks |

GitHub Pages يستضيف ملفات HTML/CSS/JS ثابتة فقط (لا يوجد خادم Node يعمل هناك) — وهذا بالضبط ما
يبنيه Vite. أي منطق يحتاج مفاتيح سرّية (إرسال الإيميلات، صلاحيات الـAdmin الكاملة) يعمل داخل
Supabase، ولا يظهر أبدًا في الكود المُرسل للمتصفح.

```
motlob/
├── src/                      # تطبيق React (الواجهة)
│   ├── pages/                # الصفحات: الرئيسية، اطلب عربيتك، الطلبات، قدّم عرضك، لوحة التحكم...
│   ├── components/           # مكونات مشتركة (Navbar, Footer, RequestCard, RequestDrawer...)
│   ├── context/              # AdminAuthContext (Supabase Auth), ToastContext
│   └── lib/                  # عميل Supabase، الثوابت، دوال التنسيق
├── public/assets/            # اللوجو
├── supabase/
│   ├── schema.sql            # الجداول + الدوال + الـTriggers + View الطلبات العامة
│   ├── policies.sql          # قواعد Row Level Security
│   ├── policies-storage.sql  # قواعد تخزين صور العروض
│   ├── seed-demo.sql         # بيانات تجريبية اختيارية (لا تُشغَّل على Production)
│   └── functions/            # Edge Functions لإرسال إيميلات الـAdmin
│       ├── notify-new-request/
│       └── notify-new-offer/
└── .github/workflows/deploy.yml   # بناء ونشر تلقائي على GitHub Pages
```

---

## 1) إعداد Supabase (خطوة بخطوة)

1. أنشئ مشروعًا جديدًا على [supabase.com](https://supabase.com).
2. من **SQL Editor**، شغّل الملفات التالية **بالترتيب**:
   1. `supabase/schema.sql`
   2. `supabase/policies.sql`
   3. `supabase/policies-storage.sql`
   4. (اختياري، للتجربة فقط) `supabase/seed-demo.sql`
3. من **Project Settings → API**، انسخ:
   - `Project URL` → هيبقى `VITE_SUPABASE_URL`
   - `anon public key` → هيبقى `VITE_SUPABASE_ANON_KEY`

   هذان المفتاحان **عامّان (public)** وآمن وضعهما داخل كود الواجهة الثابت — كل الحماية الفعلية
   تتم عبر RLS policies في `policies.sql`، وليس بإخفاء المفتاح.

### إنشاء أول حساب Admin

لا يوجد تسجيل ذاتي كـAdmin عن قصد. الخطوات:

1. من **Authentication → Users → Add user**، أنشئ مستخدمًا بالبريد وكلمة المرور اللي هتستخدمها
   للدخول على لوحة التحكم.
2. من **SQL Editor**، شغّل:
   ```sql
   insert into admins (user_id, email)
   select id, email from auth.users where email = 'admin@example.com';
   ```
   (غيّر الإيميل لإيميلك الفعلي).
3. سجّل الدخول من `/#/admin-login` بنفس البريد وكلمة المرور.

---

## 2) إعداد إشعارات البريد الإلكتروني (Edge Functions)

الإيميلات الحالية بتتبعت على: **`captain.america.steve.grant.rogers@gmail.com`**
(مضبوطة كقيمة افتراضية داخل الكود، ويُفضّل ضبطها أيضًا كـ Secret كما بالأسفل حتى تقدر تغيّرها
لاحقًا من غير ما تعدّل كود).

1. ثبّت [Supabase CLI](https://supabase.com/docs/guides/cli) وسجّل الدخول:
   ```bash
   npm install -g supabase
   supabase login
   supabase link --project-ref YOUR-PROJECT-REF
   ```
2. أنشئ حساب مجاني على [resend.com](https://resend.com) واحصل على `API Key`.
3. اضبط الـSecrets:
   ```bash
   supabase secrets set RESEND_API_KEY=re_xxx
   supabase secrets set SENDER_EMAIL="Motlob <notifications@yourdomain.com>"
   supabase secrets set ADMIN_EMAIL=captain.america.steve.grant.rogers@gmail.com
   supabase secrets set DASHBOARD_URL=https://YOUR-GITHUB-USERNAME.github.io/motlob/#/admin
   ```
   > ملاحظة: بدون دومين خاص متحقق منه في Resend، استخدم مؤقتًا `onboarding@resend.dev` كـ
   > `SENDER_EMAIL` للتجربة فقط.
4. انشر الدوال:
   ```bash
   supabase functions deploy notify-new-request
   supabase functions deploy notify-new-offer
   ```
5. من **Database → Webhooks** في لوحة Supabase، أنشئ Webhook لكل جدول:

   | الاسم | الجدول | الحدث | الوجهة |
   |---|---|---|---|
   | notify-new-request | `buyer_requests` | `INSERT` | Edge Function: `notify-new-request` |
   | notify-new-offer | `seller_offers` | `INSERT` | Edge Function: `notify-new-offer` |

   هذا يضمن إرسال إيميل تلقائي للـAdmin عند وصول أي طلب أو عرض جديد، من غير ما يعرف المشتري أو
   البائع بوجود هذا الإيميل إطلاقًا — كما هو محدد في المواصفات.

---

## 3) التطوير محليًا

```bash
npm install
cp .env.example .env
# افتح .env واملأ VITE_SUPABASE_URL و VITE_SUPABASE_ANON_KEY
npm run dev
```

---

## 4) النشر على GitHub Pages

1. أنشئ مستودع جديد على GitHub وارفع المشروع:
   ```bash
   git init
   git add .
   git commit -m "Motlob MVP"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/motlob.git
   git push -u origin main
   ```
2. من **Settings → Pages**، اختر Source: **GitHub Actions**.
3. من **Settings → Secrets and variables → Actions**، أضف:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
4. أي `push` على `main` هيشغّل `.github/workflows/deploy.yml` تلقائيًا: يبني المشروع بـ
   `npm run build` وينشره على `https://YOUR-USERNAME.github.io/motlob/`.

> الـWorkflow بيضبط `base path` تلقائيًا على اسم المستودع (`/motlob/`). لو غيّرت اسم المستودع، مفيش
> حاجة تتعدل يدويًا — بياخده مباشرة من `github.event.repository.name`.

> بنستخدم `HashRouter` (روابط بصيغة `#/requests`) بدل `BrowserRouter` عن قصد: GitHub Pages
> ملفات ثابتة بدون إعادة توجيه من السيرفر (server rewrites)، فلو حد فتح `/requests` مباشرة أو
> عمل Refresh هيظهرله 404. الـHash routing بيحل المشكلة من غير أي إعداد إضافي.

---

## 5) قواعد الخصوصية المُطبَّقة فعليًا في قاعدة البيانات

هذه ليست مجرد قواعد واجهة — كلها Row Level Security على مستوى Postgres، بمعنى إنها بتتطبق حتى
لو حد حاول يستدعي الـAPI مباشرة من غير المتصفح:

- جدول `buyer_requests` **مغلق بالكامل** أمام الزوار/البائعين. لا SELECT، لا INSERT مباشر.
- تصفح الطلبات العامة بيتم فقط عبر View باسم `public_requests`، بتستثني عمدًا
  `buyer_name` / `buyer_phone` / `city`.
- إرسال طلب جديد أو عرض جديد بيتم فقط عبر دالتين (`submit_buyer_request`, `submit_seller_offer`)
  من نوع `SECURITY DEFINER` — بترجع فقط رقم الطلب/العرض، مش أي بيانات حساسة.
- حالة كل طلب/عرض (`status`) دايمًا بتتفرض على `NEW` عبر Trigger في قاعدة البيانات، بغض النظر عما
  يُرسَل من الواجهة.
- جدول `admin_notes` مغلق تمامًا إلا لأعضاء جدول `admins`.
- صور العروض تُخزَّن في Bucket **خاص** (private) — أي رفع مسموح، لكن القراءة فقط لأعضاء `admins`
  عبر Signed URLs مؤقتة.
- الترقية لعضوية Admin لا تتم إلا يدويًا من SQL Editor — لا يوجد مسار برمجي لذلك من الواجهة.

---

## 6) ما الذي لم يُبنَ عمدًا في هذا الـMVP (بحسب المواصفات)

- لا يوجد Chat مباشر بين المشتري والبائع.
- لا يوجد كشف تلقائي لرقم هاتف أي طرف للطرف الآخر.
- لا يوجد دفع إلكتروني، ولا نظام مزايدة معقّد.
- لا تُستخدم بيانات وهمية في بيئة الإنتاج (`supabase/seed-demo.sql` للتجربة المحلية فقط،
  وكل صف فيه مُعلَّم بوضوح بـ `[DEMO]`).

هذه النقاط قابلة للإضافة مستقبلًا (حسابات مستخدمين، تقييمات، إشعارات فورية، تطبيق موبايل...)
بدون إعادة هيكلة كبيرة — الـSchema مصمم لاستيعابها لاحقًا.
