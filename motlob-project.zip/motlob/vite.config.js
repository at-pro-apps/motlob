import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// GitHub Pages serves a project site at https://<user>.github.io/<repo>/,
// so every asset URL needs that `/<repo>/` prefix — otherwise CSS/JS/images
// 404 in production even though `npm run dev` looks fine locally.
//
// VITE_BASE_PATH is set automatically by .github/workflows/deploy.yml to
// "/<repo-name>/". For local dev it defaults to "/".
export default defineConfig({
  plugins: [react()],
  base: process.env.VITE_BASE_PATH || '/',
})
