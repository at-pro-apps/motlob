-- ============================================================
-- Motlob — Database schema
-- Run this in: Supabase Dashboard -> SQL Editor -> New query
-- (or via `supabase db push` if you use the Supabase CLI locally)
-- ============================================================

create extension if not exists pgcrypto;

-- ------------------------------------------------------------
-- admins: whitelist of auth.users who may use the dashboard.
-- There is no self-service admin signup on purpose — you add rows
-- here manually after creating the user in Supabase Auth.
-- ------------------------------------------------------------
create table if not exists admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  email   text not null,
  created_at timestamptz not null default now()
);

-- SECURITY DEFINER function: lets RLS policies check admin membership
-- without those policies needing direct SELECT rights on `admins`
-- themselves (which would otherwise be a chicken-and-egg RLS problem).
create or replace function is_admin()
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1 from admins where user_id = auth.uid()
  );
$$;

-- ------------------------------------------------------------
-- buyer_requests
-- ------------------------------------------------------------
create table if not exists buyer_requests (
  id           bigserial primary key,
  request_code text generated always as ('MOT-' || lpad(id::text, 6, '0')) stored,
  created_at   timestamptz not null default now(),
  status       text not null default 'NEW'
               check (status in ('NEW','UNDER_REVIEW','APPROVED','PUBLISHED','HAS_OFFERS','COMPLETED','REJECTED')),

  -- buyer (private — never exposed to sellers, see policies.sql)
  buyer_name    text not null,
  buyer_phone   text not null,
  governorate   text not null,
  city          text not null,

  -- car being requested (public once published)
  brand        text not null,
  model        text not null,
  year_from    int not null,
  year_to      int not null,
  budget_min   numeric not null,
  budget_max   numeric not null,
  max_km       numeric not null,
  transmission text not null check (transmission in ('أوتوماتيك','مانيوال','لا يهم')),
  fuel         text not null check (fuel in ('بنزين','ديزل','غاز','Hybrid','لا يهم')),
  condition    text not null check (condition in ('مستعملة','جديدة','لا يهم')),
  extra_notes  text default ''
);

-- Buyers can never set their own status: every insert (and any client
-- update, though clients cannot update this table at all — see policies)
-- is forced to NEW here, regardless of what was sent.
create or replace function force_new_request_status()
returns trigger language plpgsql as $$
begin
  new.status := 'NEW';
  return new;
end;
$$;

drop trigger if exists trg_force_new_request_status on buyer_requests;
create trigger trg_force_new_request_status
  before insert on buyer_requests
  for each row execute function force_new_request_status();

-- ------------------------------------------------------------
-- seller_offers
-- ------------------------------------------------------------
create table if not exists seller_offers (
  id          bigserial primary key,
  offer_code  text generated always as ('OFF-' || lpad(id::text, 6, '0')) stored,
  request_id  bigint not null references buyer_requests(id) on delete cascade,
  created_at  timestamptz not null default now(),
  status      text not null default 'NEW'
              check (status in ('NEW','REVIEWING','SHORTLISTED','CONTACTED','ACCEPTED','REJECTED','SOLD')),

  -- seller (private — never exposed to the buyer, see policies.sql)
  seller_name       text not null,
  seller_phone      text not null,
  seller_type       text not null check (seller_type in ('مالك سيارة','تاجر','معرض')),
  dealer_name       text default '',
  seller_governorate text not null,

  -- car being offered
  brand        text not null,
  model        text not null,
  year         int not null,
  km           numeric not null,
  price        numeric not null,
  transmission text not null check (transmission in ('أوتوماتيك','مانيوال')),
  fuel         text not null check (fuel in ('بنزين','ديزل','غاز','Hybrid')),
  condition    text not null check (condition in ('مستعملة','جديدة')),
  description  text not null,
  notes        text default '',
  images       text[] default '{}'
);

create or replace function force_new_offer_status()
returns trigger language plpgsql as $$
begin
  new.status := 'NEW';
  return new;
end;
$$;

drop trigger if exists trg_force_new_offer_status on seller_offers;
create trigger trg_force_new_offer_status
  before insert on seller_offers
  for each row execute function force_new_offer_status();

-- When a fresh offer lands on a PUBLISHED request, bump the request to
-- HAS_OFFERS automatically so it shows up correctly in the admin table.
create or replace function bump_request_on_offer()
returns trigger language plpgsql as $$
begin
  update buyer_requests
     set status = 'HAS_OFFERS'
   where id = new.request_id
     and status = 'PUBLISHED';
  return new;
end;
$$;

drop trigger if exists trg_bump_request_on_offer on seller_offers;
create trigger trg_bump_request_on_offer
  after insert on seller_offers
  for each row execute function bump_request_on_offer();

-- ------------------------------------------------------------
-- admin_notes — internal notes, never exposed to buyers or sellers
-- ------------------------------------------------------------
create table if not exists admin_notes (
  id         bigserial primary key,
  request_id bigint not null references buyer_requests(id) on delete cascade,
  note       text not null,
  created_at timestamptz not null default now(),
  created_by uuid references auth.users(id)
);

create or replace function set_note_author()
returns trigger language plpgsql as $$
begin
  new.created_by := auth.uid();
  return new;
end;
$$;

drop trigger if exists trg_set_note_author on admin_notes;
create trigger trg_set_note_author
  before insert on admin_notes
  for each row execute function set_note_author();

-- ------------------------------------------------------------
-- public_requests view — the ONLY thing sellers/anon ever query.
-- Deliberately excludes buyer_name / buyer_phone / city, and only
-- ever shows requests that an admin has published.
-- ------------------------------------------------------------
create or replace view public_requests as
select
  id, request_code, created_at, status,
  governorate, brand, model, year_from, year_to,
  budget_min, budget_max, max_km, transmission, fuel, condition, extra_notes
from buyer_requests
where status in ('PUBLISHED','HAS_OFFERS');

comment on view public_requests is
  'Public, read-only projection of buyer_requests. Excludes buyer_name/buyer_phone/city on purpose — see policies.sql for the matching grants.';

-- ============================================================
-- Public write RPCs.
--
-- The frontend never inserts into buyer_requests / seller_offers directly.
-- Both tables stay closed to anon/authenticated for SELECT (see
-- policies.sql), which means a plain INSERT ... RETURNING would fail RLS
-- when the client asks for the row back (PostgREST needs SELECT rights to
-- return the inserted row). These two SECURITY DEFINER functions insert on
-- the caller's behalf and hand back ONLY the generated code (and the new
-- offer's id, needed to name its uploaded images) — never the full row.
-- ============================================================

create or replace function submit_buyer_request(
  p_buyer_name    text,
  p_buyer_phone   text,
  p_governorate   text,
  p_city          text,
  p_brand         text,
  p_model         text,
  p_year_from     int,
  p_year_to       int,
  p_budget_min    numeric,
  p_budget_max    numeric,
  p_max_km        numeric,
  p_transmission  text,
  p_fuel          text,
  p_condition     text,
  p_extra_notes   text
) returns text
language plpgsql
security definer
set search_path = public
as $$
declare
  v_code text;
begin
  insert into buyer_requests (
    buyer_name, buyer_phone, governorate, city,
    brand, model, year_from, year_to,
    budget_min, budget_max, max_km,
    transmission, fuel, condition, extra_notes
  ) values (
    p_buyer_name, p_buyer_phone, p_governorate, p_city,
    p_brand, p_model, p_year_from, p_year_to,
    p_budget_min, p_budget_max, p_max_km,
    p_transmission, p_fuel, p_condition, coalesce(p_extra_notes, '')
  )
  returning request_code into v_code;

  return v_code;
end;
$$;

revoke all on function submit_buyer_request from public;
grant execute on function submit_buyer_request to anon, authenticated;

create or replace function submit_seller_offer(
  p_request_id        bigint,
  p_seller_name        text,
  p_seller_phone       text,
  p_seller_type        text,
  p_dealer_name        text,
  p_seller_governorate text,
  p_brand              text,
  p_model              text,
  p_year               int,
  p_km                 numeric,
  p_price              numeric,
  p_transmission       text,
  p_fuel               text,
  p_condition          text,
  p_description        text,
  p_notes              text
) returns table (id bigint, offer_code text)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_id bigint;
  v_code text;
begin
  if not exists (
    select 1 from buyer_requests r
    where r.id = p_request_id
      and r.status in ('PUBLISHED','HAS_OFFERS')
  ) then
    raise exception 'This request is not open for offers.';
  end if;

  insert into seller_offers (
    request_id, seller_name, seller_phone, seller_type, dealer_name, seller_governorate,
    brand, model, year, km, price, transmission, fuel, condition, description, notes
  ) values (
    p_request_id, p_seller_name, p_seller_phone, p_seller_type, coalesce(p_dealer_name,''), p_seller_governorate,
    p_brand, p_model, p_year, p_km, p_price, p_transmission, p_fuel, p_condition, p_description, coalesce(p_notes,'')
  )
  returning seller_offers.id, seller_offers.offer_code into v_id, v_code;

  return query select v_id, v_code;
end;
$$;

revoke all on function submit_seller_offer from public;
grant execute on function submit_seller_offer to anon, authenticated;

-- Lets a seller attach uploaded image paths to the offer they just created,
-- without ever granting UPDATE/SELECT on seller_offers itself. It only
-- accepts an offer id + image path array and blindly appends — it cannot be
-- used to change any other field.
create or replace function attach_offer_images(p_offer_id bigint, p_paths text[])
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  update seller_offers set images = p_paths where id = p_offer_id;
end;
$$;

revoke all on function attach_offer_images from public;
grant execute on function attach_offer_images to anon, authenticated;
