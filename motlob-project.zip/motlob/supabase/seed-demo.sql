-- ============================================================
-- OPTIONAL demo data — for local/staging testing only.
-- Per the product spec, fake data must never reach production and must be
-- obviously labeled as a demo. Every row below is prefixed "[DEMO]" and
-- uses placeholder contact info for exactly that reason.
--
-- Do NOT run this against your production database.
-- ============================================================

insert into buyer_requests (buyer_name, buyer_phone, governorate, city, brand, model, year_from, year_to, budget_min, budget_max, max_km, transmission, fuel, condition, extra_notes)
values
  ('[DEMO] عميل تجريبي 1', '01000000001', 'الشرقية', 'العاشر من رمضان', 'Toyota', 'Corolla', 2018, 2021, 700000, 850000, 120000, 'أوتوماتيك', 'بنزين', 'مستعملة', 'لون فاتح ومفيش حوادث. [بيانات تجريبية]'),
  ('[DEMO] عميل تجريبي 2', '01000000002', 'القاهرة', 'مدينة نصر', 'Hyundai', 'Elantra', 2019, 2022, 800000, 950000, 100000, 'أوتوماتيك', 'بنزين', 'مستعملة', '[بيانات تجريبية]');

-- Publish the first demo request so it shows up on the public board:
update buyer_requests set status = 'PUBLISHED'
where buyer_name = '[DEMO] عميل تجريبي 1';

-- Add a demo offer against it (using submit_seller_offer so the trigger/
-- status logic runs exactly as it would in production):
select submit_seller_offer(
  (select id from buyer_requests where buyer_name = '[DEMO] عميل تجريبي 1'),
  '[DEMO] معرض تجريبي', '01100000000', 'معرض', '[DEMO] معرض النجاح للسيارات', 'الإسكندرية',
  'Toyota', 'Corolla', 2021, 60000, 980000, 'أوتوماتيك', 'بنزين', 'مستعملة',
  '[بيانات تجريبية] سيارة بحالة ممتازة.', ''
);
