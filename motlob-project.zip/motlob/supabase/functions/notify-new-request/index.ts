// Called by a Supabase Database Webhook on INSERT into buyer_requests.
// See README.md for how to wire the webhook up from the Dashboard.
//
// The buyer never sees this happen — the frontend only ever shows the
// generic "تم استلام طلبك بنجاح" success screen, regardless of whether this
// email send succeeds.

import { corsHeaders } from '../_shared/cors.ts'
import { sendAdminEmail } from '../_shared/resend.ts'

function escapeHtml(s: unknown) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c] as string))
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  try {
    const payload = await req.json()
    // Database Webhook payload shape: { type, table, record, old_record, schema }
    const r = payload.record

    const dashboardUrl = Deno.env.get('DASHBOARD_URL') || 'https://YOUR-GITHUB-USERNAME.github.io/motlob/#/admin'

    const html = `
      <div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;">
        <h2 style="color:#132049;">طلب سيارة جديد - ${escapeHtml(r.request_code)}</h2>

        <h3>بيانات العميل</h3>
        <p>
          الاسم: ${escapeHtml(r.buyer_name)}<br/>
          رقم الهاتف: ${escapeHtml(r.buyer_phone)}<br/>
          المحافظة: ${escapeHtml(r.governorate)}<br/>
          المنطقة: ${escapeHtml(r.city)}
        </p>

        <h3>السيارة المطلوبة</h3>
        <p>
          الماركة: ${escapeHtml(r.brand)}<br/>
          الموديل: ${escapeHtml(r.model)}<br/>
          السنة: ${escapeHtml(r.year_from)} - ${escapeHtml(r.year_to)}<br/>
          الميزانية: ${escapeHtml(r.budget_min)} - ${escapeHtml(r.budget_max)} جنيه<br/>
          أقصى KM: ${escapeHtml(r.max_km)}<br/>
          ناقل الحركة: ${escapeHtml(r.transmission)}<br/>
          الوقود: ${escapeHtml(r.fuel)}<br/>
          الحالة: ${escapeHtml(r.condition)}
        </p>

        ${r.extra_notes ? `<h3>المواصفات الإضافية</h3><p>${escapeHtml(r.extra_notes)}</p>` : ''}

        <p style="color:#8A8F9C;font-size:13px;">وقت إرسال الطلب: ${escapeHtml(r.created_at)}</p>

        <p><a href="${dashboardUrl}" style="display:inline-block;background:#132049;color:#fff;padding:12px 20px;border-radius:8px;text-decoration:none;">فتح الطلب في لوحة التحكم</a></p>
      </div>
    `

    await sendAdminEmail(`طلب سيارة جديد - ${r.request_code}`, html)

    return new Response(JSON.stringify({ ok: true }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  } catch (err) {
    console.error(err)
    return new Response(JSON.stringify({ ok: false, error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }
})
