// Called by a Supabase Database Webhook on INSERT into seller_offers.
// See README.md for how to wire the webhook up from the Dashboard.
//
// The seller never sees this happen — the frontend only ever shows the
// generic "تم استلام عرضك بنجاح" success screen, regardless of whether this
// email send succeeds.

import { corsHeaders } from '../_shared/cors.ts'
import { sendAdminEmail } from '../_shared/resend.ts'
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

function escapeHtml(s: unknown) {
  return String(s ?? '').replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c] as string))
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })

  try {
    const payload = await req.json()
    const o = payload.record

    // Look up the parent request's code just for a friendlier email —
    // uses the service role key, which only ever lives in this server-side
    // function's environment, never in the frontend bundle.
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    )
    const { data: requestRow } = await supabaseAdmin
      .from('buyer_requests')
      .select('request_code')
      .eq('id', o.request_id)
      .maybeSingle()
    const requestCode = requestRow?.request_code || `#${o.request_id}`

    const dashboardUrl = Deno.env.get('DASHBOARD_URL') || 'https://YOUR-GITHUB-USERNAME.github.io/motlob/#/admin'

    const html = `
      <div style="font-family:Arial,sans-serif;max-width:560px;margin:auto;">
        <h2 style="color:#132049;">عرض جديد على طلب ${escapeHtml(requestCode)}</h2>

        <p>رقم العرض: ${escapeHtml(o.offer_code)}<br/>طلب السيارة: ${escapeHtml(requestCode)}</p>

        <h3>بيانات البائع</h3>
        <p>
          الاسم: ${escapeHtml(o.seller_name)}<br/>
          رقم الهاتف: ${escapeHtml(o.seller_phone)}<br/>
          نوع البائع: ${escapeHtml(o.seller_type)}<br/>
          اسم المعرض: ${escapeHtml(o.dealer_name)}<br/>
          المحافظة: ${escapeHtml(o.seller_governorate)}
        </p>

        <h3>السيارة</h3>
        <p>
          الماركة: ${escapeHtml(o.brand)}<br/>
          الموديل: ${escapeHtml(o.model)}<br/>
          السنة: ${escapeHtml(o.year)}<br/>
          KM: ${escapeHtml(o.km)}<br/>
          السعر: ${escapeHtml(o.price)}<br/>
          ناقل الحركة: ${escapeHtml(o.transmission)}<br/>
          الوقود: ${escapeHtml(o.fuel)}<br/>
          الحالة: ${escapeHtml(o.condition)}
        </p>

        <h3>الوصف</h3>
        <p>${escapeHtml(o.description)}</p>
        ${o.images?.length ? `<p style="color:#8A8F9C;font-size:13px;">عدد الصور المرفقة: ${o.images.length} (متاحة في لوحة التحكم)</p>` : ''}

        <p><a href="${dashboardUrl}" style="display:inline-block;background:#C31C2A;color:#fff;padding:12px 20px;border-radius:8px;text-decoration:none;">فتح العرض في لوحة التحكم</a></p>
      </div>
    `

    await sendAdminEmail(`عرض جديد على طلب ${requestCode}`, html)

    return new Response(JSON.stringify({ ok: true }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  } catch (err) {
    console.error(err)
    return new Response(JSON.stringify({ ok: false, error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    })
  }
})
