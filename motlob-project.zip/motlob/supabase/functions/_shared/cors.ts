// Database Webhooks call these functions server-to-server, so CORS headers
// aren't strictly required — but they're harmless to include and make the
// functions easy to test with a manual curl/fetch from a browser console.
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}
