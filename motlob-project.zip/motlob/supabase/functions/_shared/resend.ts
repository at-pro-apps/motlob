// Thin wrapper around the Resend API (https://resend.com). Swap this file
// out if you'd rather use another transactional email provider — nothing
// else in the two functions needs to change.

const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY')
const SENDER_EMAIL = Deno.env.get('SENDER_EMAIL') || 'Motlob <onboarding@resend.dev>'

// This is the address every admin notification goes to. It's read from the
// ADMIN_EMAIL secret so it can be changed without redeploying code — see
// README.md for `supabase secrets set`. The literal string below is only a
// fallback in case that secret hasn't been set yet, so the platform still
// works out of the box.
const ADMIN_EMAIL = Deno.env.get('ADMIN_EMAIL') || 'captain.america.steve.grant.rogers@gmail.com'

export async function sendAdminEmail(subject: string, html: string) {
  if (!RESEND_API_KEY) {
    console.error('RESEND_API_KEY is not set — skipping email send. Set it with `supabase secrets set RESEND_API_KEY=...`.')
    return { skipped: true }
  }

  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${RESEND_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      from: SENDER_EMAIL,
      to: [ADMIN_EMAIL],
      subject,
      html,
    }),
  })

  if (!res.ok) {
    const text = await res.text()
    console.error('Resend API error:', res.status, text)
    throw new Error(`Resend API error: ${res.status}`)
  }

  return res.json()
}

export { ADMIN_EMAIL }
