-- ============================================================
-- Motlob — Row Level Security policies
-- Run this AFTER schema.sql, in the same SQL Editor.
--
-- Design in one line: buyer_requests and seller_offers are completely
-- closed to anon/authenticated for SELECT/INSERT/UPDATE/DELETE. The only
-- way in for the public is the SECURITY DEFINER RPC functions defined at
-- the end of schema.sql, and the only way to browse requests is the
-- public_requests view. Admins get full access via is_admin().
-- ============================================================

-- ------------------------------------------------------------
-- admins
-- ------------------------------------------------------------
alter table admins enable row level security;

create policy "admins can read their own membership row"
  on admins for select
  using (user_id = auth.uid());

-- No insert/update/delete policy -> only manageable from the Supabase
-- Dashboard (as the postgres role, which bypasses RLS). Promoting someone
-- to Admin should never be possible from the public frontend.

-- ------------------------------------------------------------
-- buyer_requests — no anon/authenticated policies at all.
-- Writes only happen via submit_buyer_request() (SECURITY DEFINER).
-- Reads only happen via the public_requests view (for anon/authenticated)
-- or the admin policies below (for admins).
-- ------------------------------------------------------------
alter table buyer_requests enable row level security;

create policy "admins can read all buyer requests"
  on buyer_requests for select
  to authenticated
  using (is_admin());

create policy "admins can update buyer requests"
  on buyer_requests for update
  to authenticated
  using (is_admin())
  with check (is_admin());

create policy "admins can delete buyer requests"
  on buyer_requests for delete
  to authenticated
  using (is_admin());

grant select on public_requests to anon, authenticated;

-- ------------------------------------------------------------
-- seller_offers — same pattern: writes only via submit_seller_offer()
-- and attach_offer_images(). No direct anon/authenticated access.
-- ------------------------------------------------------------
alter table seller_offers enable row level security;

create policy "admins can read all offers"
  on seller_offers for select
  to authenticated
  using (is_admin());

create policy "admins can update offers"
  on seller_offers for update
  to authenticated
  using (is_admin())
  with check (is_admin());

create policy "admins can delete offers"
  on seller_offers for delete
  to authenticated
  using (is_admin());

-- ------------------------------------------------------------
-- admin_notes — fully private, admin-only in both directions
-- ------------------------------------------------------------
alter table admin_notes enable row level security;

create policy "admins can read notes"
  on admin_notes for select
  to authenticated
  using (is_admin());

create policy "admins can add notes"
  on admin_notes for insert
  to authenticated
  with check (is_admin());

create policy "admins can delete notes"
  on admin_notes for delete
  to authenticated
  using (is_admin());
