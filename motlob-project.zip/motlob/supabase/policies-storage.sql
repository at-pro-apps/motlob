-- ============================================================
-- Motlob — Storage bucket + policies for seller-uploaded car photos
-- Run this AFTER schema.sql and policies.sql.
-- ============================================================

-- Create a PRIVATE bucket (public = false): images are for admin review
-- only, matching "لن تُنشر بدون موافقتك" from the spec. Nothing is served
-- over a public URL — admins fetch images via signed URLs from the
-- dashboard, using their authenticated session.
insert into storage.buckets (id, name, public)
values ('offer-images', 'offer-images', false)
on conflict (id) do nothing;

-- Sellers (anonymous, no login) can upload — but only upload. They cannot
-- list, read, overwrite, or delete anything in the bucket, including their
-- own just-uploaded files, which stops the bucket being used to browse
-- other people's photos.
create policy "anyone can upload offer images"
  on storage.objects for insert
  to anon, authenticated
  with check (bucket_id = 'offer-images');

-- Only admins can read (and therefore view/download) offer images.
create policy "admins can read offer images"
  on storage.objects for select
  to authenticated
  using (bucket_id = 'offer-images' and is_admin());

create policy "admins can delete offer images"
  on storage.objects for delete
  to authenticated
  using (bucket_id = 'offer-images' and is_admin());
